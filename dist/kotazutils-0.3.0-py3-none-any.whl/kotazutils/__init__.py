__version__ = "0.3.0"
__author__ = "Kotaz"
__license__ = "MIT"
__email__ = "semechkagent@gmail.com"

__description__ = """
KotazUtils is a collection of utilities for Python.
"""
