import lupa
from lupa import LuaRuntime 

lua = LuaRuntime(unpack_returned_tuples=True)

# TODO: Start implementing the lua module